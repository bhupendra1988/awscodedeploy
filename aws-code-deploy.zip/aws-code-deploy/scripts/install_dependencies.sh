#!/bin/bash
yum install java -y
yum install wget -y
