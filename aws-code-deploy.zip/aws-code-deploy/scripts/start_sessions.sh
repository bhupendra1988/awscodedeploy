#!/bin/bash
/opt/tomcat/apache-tomcat-7.0.92/bin/startup.sh
